<?php 
use controllers\PagesController;
use controllersUse\UsersController;


$router->get("",[PagesController::class,"home"]);
$router->get("about",[PagesController::class,"about"]);
$router->get("contact",[PagesController::class,"contact"]);
$router->get("order",[PagesController::class,"order"]);
$router->get("customer",[PagesController::class,"customer"]);
$router->get("index",[UsersController::class,"index"]);
$router->post("names",[PagesController::class,"createUser"]);

?>