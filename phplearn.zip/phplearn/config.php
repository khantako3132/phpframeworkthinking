<?php 
return [
    'database' => [
        "username" => "admin",
        "password"  => "123456",
        "dbName"    => "userdb",
        "host"      => "mysql:host=localhost"
    ]
    ];


?>