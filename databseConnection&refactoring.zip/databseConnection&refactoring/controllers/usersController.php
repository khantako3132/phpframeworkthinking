<?php 
namespace controllersUse;
use core\App;
class UsersController{
    public function index(){
        view('index',[
            "users" => App::get('database')->selectAll('user')
        ]);
    }
}

?>