<?php 

class queryBuilder{
    protected $pdo;
    public function __construct($pdo)
    {
        return $this->pdo = $pdo;
    }
    public function selectAll($table){
        $statement = $this->pdo->prepare("Select * from $table");
        $statement->execute();
        return $statement->fetchAll(PDO::FETCH_OBJ);
    
    }
    public function insert($dataArr,$table)
    {
        $cols = implode(",",array_keys($dataArr));
        $getDataKeys = array_keys($dataArr);
        $questionMarks  = "";
        foreach($getDataKeys as $key){
            $questionMarks .= "?,";
        };
        $questionMarks = rtrim($questionMarks,",");
        $sqlInsert = "insert into $table ($cols) values ($questionMarks)";
        $statement = $this->pdo->prepare($sqlInsert);
        $getDataValues = array_values($dataArr);
        $statement->execute($getDataValues);
    }

}

?>