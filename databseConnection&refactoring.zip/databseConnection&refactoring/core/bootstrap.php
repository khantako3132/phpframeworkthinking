<?php 
// require "core/router.php";
// require "core/request.php";
// require "core/database/connection.php";
// require "core/database/queryBuilder.php";
use core\App;
require "core/function.php";
App::bind("config", require "config.php");
App::bind("database",new queryBuilder(
    Connection::make(App::get('config')['database'])
));
;
?>