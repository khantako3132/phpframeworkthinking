<nav>
    <a href="/">Home</a>
    <a href="/about">About</a>
    <a href="/contact">Contact</a>
    <a href="/order">Order</a>
    <a href="/customer">Customer</a>
</nav>