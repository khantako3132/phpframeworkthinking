<?php require "partials/header.php"?>

<h1>This is your name.</h1>
<?php foreach($users as $user) :?>
    <?= "<li>My name is ".$user->name." and My ages is ".$user->age." years old</li>";?>
<?php endforeach ?>
<h1>Enter your name. </h1>

    <form action="/names" method="POST">
    <input type="text" name="name">
    <input type="text" name="age">
    <input type="submit" value="submit">
 
    </form>


<?php require "partials/footer.php"?>